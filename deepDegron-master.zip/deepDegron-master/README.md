# deepDegron

deepDegron is a deep learning model to predict degron sequences. It is trained on systematic assays that measure protein degradation.
